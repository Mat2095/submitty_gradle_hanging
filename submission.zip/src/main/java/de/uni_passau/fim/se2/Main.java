package de.uni_passau.fim.se2;

public class Main {

    public static void main(String[] args) {
        System.out.print("Hello, world!");
    }
}
